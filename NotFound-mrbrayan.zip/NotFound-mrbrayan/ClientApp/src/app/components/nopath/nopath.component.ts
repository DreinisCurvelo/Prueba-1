import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-nopath',
  templateUrl: './nopath.component.html',
  styleUrls: ['./nopath.component.css']
})
export class NopathComponent implements OnInit {

  constructor() { }

  ngOnInit(): void { }

}
